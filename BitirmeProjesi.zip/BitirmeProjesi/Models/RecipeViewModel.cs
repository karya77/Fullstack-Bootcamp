using System.ComponentModel.DataAnnotations;
using BitirmeProjesi.Data;

namespace BitirmeProjesi.Models
{
    public class RecipeViewModel
    {
        public int RecipeId { get; set; }
        [Required]
        [StringLength(50)]
        public string RecipeTitle { get; set; }
        public string RecipeIngredients{get; set;}
        public string RecipeExplanation{get; set;}
        public string RecipeImage{get; set;}

        

    }
}