using System.Diagnostics.CodeAnalysis;
using System.Linq.Expressions;
using System.Runtime.CompilerServices;
using BitirmeProjesi.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SQLitePCL;

namespace RecipeControllers;

public class RecipeController:Controller{
    private readonly DataContext _context;

    public RecipeController(DataContext context){
        _context=context;
    }

    public async Task<IActionResult> Index(){
      
      
     return View(await _context.Recipes.ToListAsync());}
//-----------
     public IActionResult Create(){
        return View();
    }

    [HttpPost] 
    public async Task<IActionResult> Create(Recipe model){
            _context.Recipes.Add(model);
            await _context.SaveChangesAsync();
            return RedirectToAction("Index","Recipe");
    }
//-----------
    [HttpGet]
    public async Task<IActionResult> Edit(int? id){
        if(id==null){
            return NotFound();
        }
        var rcp=await _context.Recipes.FindAsync(id);
        if (rcp ==null){
            return NotFound();
        }
        return View(rcp);
    }

    [HttpPost]
     public async Task<IActionResult> Edit(int? id,Recipe model){
        if(id !=model.RecipeId){
            return NotFound();
        }

        if (ModelState.IsValid){
            try{
                _context.Update(model);
                await _context.SaveChangesAsync();
            } catch(DbUpdateConcurrencyException){
                if(!_context.Recipes.Any(o=>o.RecipeId==model.RecipeId)){
                    return NotFound();
                } else{
                    throw;
                }
            }
            return RedirectToAction("Index");

        }
        return View(model);
     }
//-----------
     [HttpGet]
    public async Task<IActionResult> Delete(int? id){
      if (id==null){
        return NotFound();
      }
      var recipe=await _context.Recipes.FindAsync(id);

      if(recipe == null){
        return NotFound();
      }
        return View(recipe);
    }

    [HttpPost]
     public async Task<IActionResult> Delete([FromForm] int id){
        var recipe=await _context.Recipes.FindAsync(id);
        if(recipe ==null){
            return NotFound();
        }
        _context.Recipes.Remove(recipe);
        await _context.SaveChangesAsync();
        return RedirectToAction("Index");
     }
//-----------
     public async Task<IActionResult> List(){
        return View(await _context.Recipes.ToListAsync());
     }
//-----------
     public async Task<IActionResult> Details(int id){
            var recipes = await _context.Recipes.FindAsync(id);
            return View(recipes);
    }
}



     
