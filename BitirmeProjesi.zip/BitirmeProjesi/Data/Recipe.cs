using System.ComponentModel.DataAnnotations;

namespace BitirmeProjesi.Data
{
    public class Recipe{
        public int RecipeId { get; set; }
         
        public string? RecipeTitle { get; set; }
        
        
        public string? RecipeImage { get; set; }
        
        
        public string? RecipeIngredients { get; set; }

        public string? RecipeExplanation { get; set; }


        
          
    
    }
}